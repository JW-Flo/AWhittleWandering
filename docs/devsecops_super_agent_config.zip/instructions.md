# Copilot Agent Instructions
1. Analyze the repo for Python + FastAPI, Node.js, Cloudflare Workers.
2. Implement Plan → Diff → Apply → Test → Commit → Deploy workflow.
3. Integrate Semgrep, Bandit, Trivy for security scans.
4. Refactor code with logging, tracing, and metrics.
5. Configure `.vscode/tasks.json` and GitHub Actions workflows.
6. Add Terraform IaC scaffolding for Cloudflare Workers and AWS Lambda (future).
7. Use environment variables or vaults for secrets.
